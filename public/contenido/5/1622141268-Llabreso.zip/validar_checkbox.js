let validar_checkbox = function()
{
	let illes = document.querySelectorAll("input[name='illes']");
	let contador = 0;

	for (let i = 0; i < illes.length; i++) if (illes[i].checked) contador++;
	if (contador >= 2) return true;
	document.querySelector("#error_illes").innerHTML = "Al menys, dues";
	return false;
}