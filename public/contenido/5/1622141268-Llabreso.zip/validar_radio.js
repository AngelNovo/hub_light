let validar_radio = function()
{
	let illes = document.querySelectorAll("input[name='illes']");

	for (let i = 0; i < illes.length; i++) if (illes[i].checked) return true;
	document.querySelector("#error_illes").innerHTML = "Escollir-ne un";
	return false;
}